using NAudio.Wave;
using NAudio.Wave.SampleProviders;

namespace LekCueTest;

public sealed class AudioEngine : IDisposable
{
    SharedTrack? _track;
    TrackReader? _master, _cue;
    WaveOutEvent? _outMaster, _outCue;
    AsioOut? _asio;
    WaveInEvent? _mic;
    BufferedWaveProvider? _micBuf;
    int _shiftMs;

    public event Action<float>? MicLevel;
    public bool HasTrack => _track != null;
    public bool Playing { get; private set; }
    public TimeSpan Duration => _track?.Duration ?? TimeSpan.Zero;
    public bool Finished => _master != null && _track != null && _master.PositionFrames >= _track.Frames + 4800;

    public void Load(string path)
    {
        Stop();
        _track = SharedTrack.Load(path);
    }

    static long MsToFrames(int ms) => (long)ms * SharedTrack.Rate / 1000;

    /// <summary>Master = фанера (нормальное время) + микрофон. Cue = та же фанера, указатель впереди на shiftMs.</summary>
    ISampleProvider BuildChains(int micDevice, int shiftMs)
    {
        _shiftMs = shiftMs;
        _master = new TrackReader(_track!);
        _cue = new TrackReader(_track!);
        _cue.Seek(MsToFrames(shiftMs));

        ISampleProvider masterMix = _master;
        if (micDevice >= 0)
        {
            var fmt = new WaveFormat(SharedTrack.Rate, 16, 1);
            _mic = new WaveInEvent { DeviceNumber = micDevice, WaveFormat = fmt, BufferMilliseconds = 20 };
            _micBuf = new BufferedWaveProvider(fmt)
            {
                DiscardOnBufferOverflow = true,
                BufferDuration = TimeSpan.FromMilliseconds(120)
            };
            _mic.DataAvailable += (s, e) =>
            {
                _micBuf.AddSamples(e.Buffer, 0, e.BytesRecorded);
                MicLevel?.Invoke(Peak(e.Buffer, e.BytesRecorded));
            };
            var micStereo = new MonoToStereoSampleProvider(_micBuf.ToSampleProvider());
            // Микрофон суммируется ТОЛЬКО в Master. В Cue его нет.
            masterMix = new MixingSampleProvider(new ISampleProvider[] { _master, micStereo }) { ReadFully = true };
        }
        return masterMix;
    }

    static float Peak(byte[] b, int n)
    {
        int max = 0;
        for (int i = 0; i + 1 < n; i += 2)
        {
            int v = Math.Abs((int)BitConverter.ToInt16(b, i));
            if (v > max) max = v;
        }
        return max / 32768f;
    }

    /// <summary>Режим «без карты»: два обычных устройства вывода (колонки + наушники).</summary>
    public void StartTwoDevices(int masterDev, int cueDev, int micDev, int shiftMs)
    {
        Stop();
        var masterMix = BuildChains(micDev, shiftMs);
        _outMaster = new WaveOutEvent { DeviceNumber = masterDev, DesiredLatency = 80, NumberOfBuffers = 3 };
        _outCue = new WaveOutEvent { DeviceNumber = cueDev, DesiredLatency = 80, NumberOfBuffers = 3 };
        _outMaster.Init(masterMix.ToWaveProvider());
        _outCue.Init(_cue!.ToWaveProvider());
        _mic?.StartRecording();
        _outMaster.Play();
        _outCue.Play();
        Playing = true;
    }

    /// <summary>Режим «с картой»: одна ASIO-карта, Зал = каналы offset+1..2, Наушники = offset+3..4.</summary>
    public void StartAsio(string driver, int channelOffset, int micDev, int shiftMs)
    {
        Stop();
        var masterMix = BuildChains(micDev, shiftMs);
        var mux = new MultiplexingSampleProvider(new[] { masterMix, (ISampleProvider)_cue! }, 4);
        mux.ConnectInputToOutput(0, 0);
        mux.ConnectInputToOutput(1, 1);
        mux.ConnectInputToOutput(2, 2);
        mux.ConnectInputToOutput(3, 3);
        _asio = new AsioOut(driver) { ChannelOffset = channelOffset };
        _asio.Init(mux.ToWaveProvider());
        _mic?.StartRecording();
        _asio.Play();
        Playing = true;
    }

    /// <summary>Сдвиг можно менять на лету: двигаем только указатель наушников.</summary>
    public void SetShift(int ms)
    {
        if (_cue == null) return;
        _cue.Shift(MsToFrames(ms - _shiftMs));
        _shiftMs = ms;
    }

    public void Stop()
    {
        Playing = false;
        try { _mic?.StopRecording(); } catch { }
        _mic?.Dispose(); _mic = null; _micBuf = null;
        _outMaster?.Dispose(); _outMaster = null;
        _outCue?.Dispose(); _outCue = null;
        _asio?.Dispose(); _asio = null;
    }

    public void Dispose() => Stop();
}
