using NAudio.Wave;
using NAudio.Wave.SampleProviders;

namespace LekCueTest;

/// <summary>Одна фанера в памяти (48 кГц, стерео, float). Копий нет, читают все по своим указателям.</summary>
public sealed class SharedTrack
{
    public const int Rate = 48000;
    public float[] Data = Array.Empty<float>();
    public WaveFormat Format = WaveFormat.CreateIEEEFloatWaveFormat(Rate, 2);
    public long Frames => Data.Length / 2;
    public TimeSpan Duration => TimeSpan.FromSeconds((double)Frames / Rate);

    public static SharedTrack Load(string path)
    {
        using var reader = new AudioFileReader(path);
        ISampleProvider sp = reader;
        if (sp.WaveFormat.Channels == 1) sp = new MonoToStereoSampleProvider(sp);
        else if (sp.WaveFormat.Channels != 2) throw new NotSupportedException("Нужен моно или стерео файл.");
        if (sp.WaveFormat.SampleRate != Rate) sp = new WdlResamplingSampleProvider(sp, Rate);

        var ms = new MemoryStream();
        var buf = new float[Rate * 2];
        var bytes = new byte[buf.Length * 4];
        int n;
        while ((n = sp.Read(buf, 0, buf.Length)) > 0)
        {
            Buffer.BlockCopy(buf, 0, bytes, 0, n * 4);
            ms.Write(bytes, 0, n * 4);
        }
        var data = new float[ms.Length / 4];
        Buffer.BlockCopy(ms.GetBuffer(), 0, data, 0, (int)ms.Length);
        return new SharedTrack { Data = data };
    }
}

/// <summary>Указатель чтения (Read Pointer) по общему массиву. Свой на каждый выход.</summary>
public sealed class TrackReader : ISampleProvider
{
    readonly SharedTrack _t;
    readonly object _lock = new();
    long _pos; // в сэмплах (канал 0, канал 1, ...)

    public TrackReader(SharedTrack t) => _t = t;
    public WaveFormat WaveFormat => _t.Format;

    public long PositionFrames { get { lock (_lock) return _pos / 2; } }
    public void Seek(long frames) { lock (_lock) _pos = Math.Max(0, frames) * 2; }
    public void Shift(long frames) { lock (_lock) _pos = Math.Max(0, _pos + frames * 2); }

    public int Read(float[] buffer, int offset, int count)
    {
        long p;
        lock (_lock) { p = _pos; _pos += count; }
        var d = _t.Data;
        int zerosBefore = p < 0 ? (int)Math.Min(count, -p) : 0;
        Array.Clear(buffer, offset, zerosBefore);
        long src = Math.Max(p, 0);
        int want = count - zerosBefore;
        int have = (int)Math.Max(0, Math.Min(want, d.Length - src));
        if (have > 0) Array.Copy(d, src, buffer, offset + zerosBefore, have);
        Array.Clear(buffer, offset + zerosBefore + have, want - have);
        return count; // после конца файла отдаём тишину, указатель идёт дальше
    }
}
