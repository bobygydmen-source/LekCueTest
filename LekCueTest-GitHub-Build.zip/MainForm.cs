using NAudio.Wave;

namespace LekCueTest;

public sealed class MainForm : Form
{
    readonly AudioEngine _eng = new();
    readonly TableLayoutPanel _t = new() { ColumnCount = 2, AutoSize = true, AutoSizeMode = AutoSizeMode.GrowAndShrink, Padding = new Padding(14) };
    readonly RadioButton rbNoCard = new() { Text = "Без карты: два обычных устройства (WaveOut)", Checked = true, AutoSize = true };
    readonly RadioButton rbAsio = new() { Text = "С картой: одна ASIO-карта (Зал = каналы 1–2, Наушники = 3–4)", AutoSize = true };
    readonly ComboBox cbMaster = Combo(), cbCue = Combo(), cbMic = Combo(), cbAsio = Combo();
    readonly NumericUpDown nudCh = new() { Minimum = 0, Maximum = 60, Value = 0, Width = 60 };
    readonly Button btnLoad = new() { Text = "📂 Загрузить фанеру (MP3/WAV)", AutoSize = true, Padding = new Padding(6) };
    readonly Button btnPlay = new() { Text = "▶ PLAY", Width = 150, Height = 40, Font = new Font("Segoe UI", 12, FontStyle.Bold) };
    readonly Label lblFile = new() { Text = "Файл не выбран", AutoSize = true };
    readonly Label lblShift = new() { AutoSize = true };
    readonly Label lblStatus = new() { AutoSize = true, ForeColor = Color.DimGray, MaximumSize = new Size(480, 0) };
    readonly TrackBar trackShift = new() { Minimum = 0, Maximum = 200, TickFrequency = 20, Value = 80, Width = 380 };
    readonly ProgressBar pbMic = new() { Width = 380, Height = 14, Maximum = 100 };
    readonly List<Control> grpNoCard = new(), grpAsio = new();
    readonly System.Windows.Forms.Timer _timer = new() { Interval = 200 };

    static ComboBox Combo() => new() { DropDownStyle = ComboBoxStyle.DropDownList, Width = 380 };

    public MainForm()
    {
        Text = "LEK CUE TEST: тестовый стенд синхронизации";
        AutoSize = true; AutoSizeMode = AutoSizeMode.GrowAndShrink;
        FormBorderStyle = FormBorderStyle.FixedDialog; MaximizeBox = false;
        StartPosition = FormStartPosition.CenterScreen;
        Font = new Font("Segoe UI", 9.5f);

        Span(rbNoCard); Span(rbAsio);
        Row("🔊 Выход в Зал (Master):", cbMaster, grpNoCard);
        Row("🎧 Выход в Наушники (Cue):", cbCue, grpNoCard);
        Row("ASIO-драйвер карты:", cbAsio, grpAsio);
        Row("Первый выходной канал:", nudCh, grpAsio);
        Row("🎤 Микрофон (только в Зал):", cbMic);
        Row("", btnLoad); Row("Файл:", lblFile);
        Row("", btnPlay);
        Row("Сдвиг для наушников:", trackShift); Row("", lblShift);
        Row("Индикатор микрофона:", pbMic);
        Span(lblStatus);
        Controls.Add(_t);

        for (int i = 0; i < WaveOut.DeviceCount; i++)
        {
            var name = WaveOut.GetCapabilities(i).ProductName;
            cbMaster.Items.Add(name); cbCue.Items.Add(name);
        }
        if (cbMaster.Items.Count > 0) cbMaster.SelectedIndex = 0;
        if (cbCue.Items.Count > 0) cbCue.SelectedIndex = Math.Min(1, cbCue.Items.Count - 1);

        cbMic.Items.Add("(без микрофона)");
        for (int i = 0; i < WaveIn.DeviceCount; i++) cbMic.Items.Add(WaveIn.GetCapabilities(i).ProductName);
        cbMic.SelectedIndex = cbMic.Items.Count > 1 ? 1 : 0;

        foreach (var d in AsioOut.GetDriverNames()) cbAsio.Items.Add(d);
        if (cbAsio.Items.Count > 0) cbAsio.SelectedIndex = 0;
        else rbAsio.Text += "  [ASIO-драйверы не найдены]";

        rbNoCard.CheckedChanged += (s, e) => ApplyMode();
        btnLoad.Click += (s, e) => LoadFile();
        btnPlay.Click += (s, e) => { if (_eng.Playing) StopAll(); else StartAll(); };
        trackShift.Scroll += (s, e) => { UpdateShiftLabel(); if (_eng.Playing) _eng.SetShift(trackShift.Value); };
        _eng.MicLevel += lvl => { if (IsHandleCreated) BeginInvoke(() => pbMic.Value = Math.Min(100, (int)(lvl * 140))); };
        _timer.Tick += (s, e) => { if (_eng.Playing && _eng.Finished) StopAll(); };
        _timer.Start();
        FormClosing += (s, e) => _eng.Dispose();

        UpdateShiftLabel(); ApplyMode();
        SetStatus("Режим «без карты»: колонки и наушники на разных устройствах. Режим «с картой»: одна ASIO-карта, точнее по времени.");
    }

    void Row(string label, Control c, List<Control>? grp = null)
    {
        var l = new Label { Text = label, AutoSize = true, Anchor = AnchorStyles.Left, Margin = new Padding(0, 6, 12, 6) };
        c.Margin = new Padding(0, 3, 0, 3);
        int r = _t.RowCount++;
        _t.Controls.Add(l, 0, r); _t.Controls.Add(c, 1, r);
        grp?.Add(l); grp?.Add(c);
    }

    void Span(Control c)
    {
        int r = _t.RowCount++;
        _t.Controls.Add(c, 0, r); _t.SetColumnSpan(c, 2);
        c.Margin = new Padding(0, 4, 0, 4);
    }

    void ApplyMode()
    {
        foreach (var c in grpNoCard) c.Visible = rbNoCard.Checked;
        foreach (var c in grpAsio) c.Visible = !rbNoCard.Checked;
        // radio-кнопки в одном контейнере, поэтому rbAsio переключается автоматически
    }

    void UpdateShiftLabel() => lblShift.Text = $"Сдвиг: -{trackShift.Value} мс (наушники слышат музыку раньше зала)";
    void SetStatus(string s) => lblStatus.Text = s;

    void LoadFile()
    {
        using var dlg = new OpenFileDialog { Filter = "Аудио (*.mp3;*.wav)|*.mp3;*.wav" };
        if (dlg.ShowDialog() != DialogResult.OK) return;
        try
        {
            StopAll();
            Cursor = Cursors.WaitCursor;
            _eng.Load(dlg.FileName);
            lblFile.Text = $"{Path.GetFileName(dlg.FileName)}  ({_eng.Duration:mm\\:ss})";
            SetStatus("Фанера загружена в память (один экземпляр).");
        }
        catch (Exception ex) { SetStatus("Ошибка загрузки: " + ex.Message); }
        finally { Cursor = Cursors.Default; }
    }

    void StartAll()
    {
        if (!_eng.HasTrack) { SetStatus("Сначала загрузите фанеру."); return; }
        try
        {
            int mic = cbMic.SelectedIndex - 1;
            if (rbAsio.Checked)
            {
                if (cbAsio.SelectedItem is not string drv) { SetStatus("ASIO-драйвер не выбран."); return; }
                _eng.StartAsio(drv, (int)nudCh.Value, mic, trackShift.Value);
            }
            else
            {
                if (cbMaster.SelectedIndex < 0 || cbCue.SelectedIndex < 0) { SetStatus("Выберите оба устройства вывода."); return; }
                if (cbMaster.SelectedIndex == cbCue.SelectedIndex)
                    SetStatus("Внимание: Зал и Наушники на одном устройстве, проверка будет бессмысленной.");
                _eng.StartTwoDevices(cbMaster.SelectedIndex, cbCue.SelectedIndex, mic, trackShift.Value);
            }
            btnPlay.Text = "⏹ STOP";
            Lock(true);
        }
        catch (Exception ex) { _eng.Stop(); SetStatus("Ошибка запуска: " + ex.Message); }
    }

    void StopAll()
    {
        _eng.Stop();
        btnPlay.Text = "▶ PLAY";
        pbMic.Value = 0;
        Lock(false);
    }

    void Lock(bool on)
    {
        rbNoCard.Enabled = rbAsio.Enabled = !on;
        cbMaster.Enabled = cbCue.Enabled = cbAsio.Enabled = cbMic.Enabled = nudCh.Enabled = !on;
        btnLoad.Enabled = !on;
    }
}
